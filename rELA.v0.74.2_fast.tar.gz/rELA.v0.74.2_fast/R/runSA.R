#'Stochastic Approximation
#'@description Estimating species interaction, environemnt preference.
#'
#'@param ocmat : array of the vectors of presence/absence status for each sample. Row is sample, column is species.
#'@param enmat : array of the vectors of environmental factors for each sample. Normalization required.
#'@param we : the parameter for adamW.
#'@param lambda : the parameter for sparse matrix
#'@param rep : number of parallel processes for the optimization.
#'@param intv : interval of iterations recording intermediate fitting results.
#'@param totalit : total iterations of optimization
#'@param threads : number of cores (threads) used for calculation. 
#'@param getall : If TRUE, the function returns all intermediate results
#'@param reporting : enable/disable the reporting function.
#'
#' @useDynLib rELA, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom foreach foreach
#' @export
runSA <- function(ocmat, enmat = NULL, rep = 128, threads = 1, we = 0.001,
                   totalit = 1000, lambda = 0.01, intv = 100,
                   runadamW = TRUE, sparse = TRUE,
                   getall = FALSE, reporting = TRUE){

  if(!sparse){lambda <- 0}
  if(!runadamW){we <- 0}

  if(!requireNamespace("foreach", quietly = TRUE)){
    stop("Package 'foreach' is required.")
  }

  suppressPackageStartupMessages(library(foreach))

  if(threads > 1){
    if(!requireNamespace("doParallel", quietly = TRUE)){
      stop("Package 'doParallel' is required when threads > 1.")
    }

    cluster <- parallel::makeCluster(threads)
    parallel::clusterCall(cluster, function(x) .libPaths(x), .libPaths())
    doParallel::registerDoParallel(cluster)
    on.exit(parallel::stopCluster(cluster), add = TRUE)
  }

  if(is.null(enmat)){

    ## ============================================== ##
    ## -- without explicit environmental variables
    ## ============================================== ##

    if(reporting){cat("Start parameter fitting:\n")}
    s <- proc.time()[3]

    if(threads > 1){
      fittingMat <- foreach::foreach(
        i = seq_len(rep),
        .packages = "rELA"
      ) %dopar% {
        SAres <- SA(
          ocData = ocmat,
          we = we,
          totalit = totalit,
          lambda = lambda,
          intv = intv
        )
        return(SAres)
      }
    }else{
      fittingMat <- foreach::foreach(i = seq_len(rep)) %do% {
        if(reporting){cat(".")}
        SAres <- SA(
          ocData = ocmat,
          we = we,
          totalit = totalit,
          lambda = lambda,
          intv = intv
        )
        return(SAres)
      }
    }

    if(reporting){
      cat(sprintf("SA: elapsed time %.2f sec\n\n", proc.time()[3] - s))
    }

    if(getall){
      return(fittingMat)
    }else{
      return(list(saEndpoint(fittingMat, ocmat), enmat))
    }

  }else{

    ## ============================================== ##
    ## -- with explicit environmental variables
    ## ============================================== ##

    if(reporting){cat("Start parameter fitting\n")}
    s <- proc.time()[3]

    if(threads > 1){
      fittingMat <- foreach::foreach(
        i = seq_len(rep),
        .packages = "rELA"
      ) %dopar% {
        SAres <- fullSA(
          ocData = ocmat,
          envData = as.matrix(enmat),
          we = we,
          totalit = totalit,
          lambda = lambda,
          intv = intv
        )
        return(SAres)
      }
    }else{
      fittingMat <- foreach::foreach(i = seq_len(rep)) %do% {
        if(reporting){cat(".")}
        SAres <- fullSA(
          ocData = ocmat,
          envData = as.matrix(enmat),
          we = we,
          totalit = totalit,
          lambda = lambda,
          intv = intv
        )
        return(SAres)
      }
    }

    if(reporting){
      cat(sprintf("SA: elapsed time %.2f sec\n\n", proc.time()[3] - s))
    }

    if(getall){
      return(fittingMat)
    }else{
      return(list(saEndpoint(fittingMat, ocmat, enmat = enmat), enmat))
    }
  }
}


#'saEndpoint: extract endpoint parameters from runSA output
#' @export
saEndpoint <- function(fittingMat, ocmat, enmat = NULL){

  num_cols <- ncol(ocmat)
  S <- ncol(ocmat)

  ## Extract endpoint parameter block from each replicate
  packed_results_end <- lapply(
    fittingMat,
    function(x) x[(nrow(x) - num_cols + 1):nrow(x), , drop = FALSE]
  )

  ## Remove the last two diagnostic columns: update/error and timepoint
  params_all <- lapply(
    packed_results_end,
    function(x) x[, 1:(ncol(x) - 2), drop = FALSE]
  )

  nrep <- length(params_all)

  ## Robustly construct array: rows x columns x replicates
  params_array <- array(
    NA_real_,
    dim = c(nrow(params_all[[1]]), ncol(params_all[[1]]), nrep)
  )

  for(i in seq_len(nrep)){
    params_array[, , i] <- as.matrix(params_all[[i]])
  }

  ## Start with mean for all parameters
  params_mat <- apply(params_array, c(1, 2), mean, na.rm = TRUE)

  ## Identify J columns
  if(is.null(enmat)){
    ## columns: h, J.1, J.2, ...
    j_cols <- 2:ncol(params_mat)
  }else{
    enmat_m <- as.matrix(enmat)
    nenv <- ncol(enmat_m)

    ## columns: h, g..., J...
    j_cols <- (2 + nenv):ncol(params_mat)
  }

  ## Replace only J columns with median across replicates
  params_mat[, j_cols] <- apply(
    params_array[, j_cols, , drop = FALSE],
    c(1, 2),
    median,
    na.rm = TRUE
  )

  rownames(params_mat) <- colnames(ocmat)

  ## Assign column names in the same style as saEndpoint()
  if(is.null(enmat)){
    colnames(params_mat) <- c(
      "h",
      paste("J", colnames(ocmat), sep = ".")
    )
  }else{
    enmat_m <- as.matrix(enmat)
    nenv <- ncol(enmat_m)

    if(nenv == 1){
      env_name <- colnames(enmat_m)
      if(is.null(env_name) || is.na(env_name[1]) || env_name[1] == ""){
        env_name <- "1"
      }
      gname <- paste("g", env_name, sep = ".")
    }else{
      gname <- paste("g", seq_len(nenv), sep = ".")
    }

    colnames(params_mat) <- c(
      "h",
      gname,
      paste("J", colnames(ocmat), sep = ".")
    )
  }

  return(params_mat)
}


#'sa2paramss: extract model parameters from runSA output
#' @useDynLib rELA, .registration=TRUE
#' @export
sa2params <- function(sa, env=NULL){
  sadim <- dim(sa[[1]])
  na <- rownames(sa[[1]])
  if(sadim[2] > sadim[1]+1){
      if(length(env)==0){env <- rep(0, sadim[2]-sadim[1]-1)} ## !!!
        he <- sa[[1]][, 1] %>% 'names<-'(na)
        je <- sa[[1]][, ((sadim[2]-sadim[1])+1):sadim[2]] %>% 'dimnames<-'(list(na,na))
        ge <- as.matrix(sa[[1]][,2:(sadim[2]-sadim[1])])  %>% 'dimnames<-' (list(na,colnames(sa[[2]])))
        hge <- (he + ge %*% env)[,1]
        #hge <- t(t(envecs %*% t(ge)) + he)
  }else{
        he <- sa[[1]][, 1] %>% 'names<-'(na)
        je <- sa[[1]][, -1] %>% 'dimnames<-'(list(na,na))
        ge <- NULL
        hge <- he
  }
  return(list(he, je, ge, hge))}


#'testfittingSA: testrun of SA across given parameter sets using subset of ocmatrix
testfittingSA <- function(ocmat,sa_results,rep,intv,enmat=NULL){
  nspecies = ncol(ocmat)
  num_timepoints <- nrow(sa_results[[1]]) / nspecies -1
  timepoints <- sapply(0:num_timepoints, function(x) (x + 1) * intv)
  serials <- 1:rep
  res_serials <- matrix(0, ncol= (num_timepoints+1), nrow=rep,
                       dimnames=list(serials,timepoints))
  for(i in 1:length(sa_results)){
    rowidx <- 1
    timeidx <- 1
    SAparams <- sa_results[[i]]
    while(rowidx < nrow(SAparams)){
      
      params<-sa2params(list(SAparams[rowidx:(rowidx+nspecies-1),
                                                  1:(ncol(SAparams)-2)],enmat))
      res_serials[i,timeidx] <- validateSA(ocmat,params[[1]],params[[2]],
                                           g=params[[3]],enmat=enmat)
      rowidx <- rowidx + nspecies
      timeidx <- timeidx + 1
    }
  }
  return(res_serials)
}
  
#'Findbp: Search the best parameters for SA fitting. If fastfitting=TRUE, then 
#'the function returns the minimum iterations allowing less than +3% errors than the minimum error.
#' @export
Findbp <- function(ocmat,enmat=NULL,ssize=0.5,we=c(0.001),
                    totalit=4000,lmd=c(0.001,0.1,0.2,0.25,0.4),
                    rep=1,nboot=96,intv=100,threads=16,tol=0.03,
                    runadamW=TRUE,sparse=TRUE,fastfitting=TRUE){

  min_points <- list()
  n_samples <- nrow(ocmat)

  if(n_samples < 2){
    stop("At least two samples are required.")
  }

  if(!runadamW){we <- c(0)}
  if(!sparse){lmd <- c(0)}

  if(!requireNamespace("foreach", quietly=TRUE)){
    stop("Package 'foreach' is required.")
  }

  suppressPackageStartupMessages(library(foreach))

  make_split <- function(){
    train_size <- floor(n_samples * ssize)

    ## Ensure both training and test sets contain at least one sample
    train_size <- max(1, min(train_size, n_samples - 1))

    train_idx <- sample(
      seq_len(n_samples),
      size = train_size,
      replace = FALSE
    )

    test_idx <- setdiff(seq_len(n_samples), train_idx)

    list(train=train_idx, test=test_idx)
  }

  split_list <- lapply(seq_len(nboot), function(i) make_split())

  if(threads > 1){
    if(!requireNamespace("doParallel", quietly=TRUE)){
      stop("Package 'doParallel' is required when threads > 1.")
    }

    cluster <- parallel::makeCluster(threads)
    parallel::clusterCall(cluster, function(x) .libPaths(x), .libPaths())

    parallel::clusterEvalQ(cluster, {
      suppressPackageStartupMessages({
        library(foreach)
        library(magrittr)
        library(rELA)
      })
      NULL
    })

    doParallel::registerDoParallel(cluster)
    on.exit(parallel::stopCluster(cluster), add=TRUE)
  }

  allresults <- list()

  for(l in lmd){
    for(w in we){

      combo_name <- paste(l, w, sep="_")

      split_results <- if(threads > 1){

        foreach::foreach(
          b=seq_len(nboot),
          .packages=c("foreach", "magrittr", "rELA"),
          .export=c("testfittingSA","validateSA", "sa2params")
        ) %dopar% {

          train_idx <- split_list[[b]]$train
          test_idx  <- split_list[[b]]$test

          octraining <- ocmat[train_idx,,drop=FALSE]
          octest     <- ocmat[test_idx,,drop=FALSE]

          if(!is.null(enmat)){
            envtraining <- enmat[train_idx,,drop=FALSE]
            envtest     <- enmat[test_idx,,drop=FALSE]
          }else{
            envtraining <- NULL
            envtest     <- NULL
          }

          sa_results <- runSA(octraining, enmat=envtraining,
                              rep=rep, threads=1, we=w,
                              totalit=totalit, lambda=l, intv=intv,
                              runadamW=runadamW, sparse=sparse,
                              getall=TRUE, reporting=FALSE)

          current_results <- testfittingSA(octest, sa_results,
                                           rep=rep, intv=intv,
                                           enmat=envtest)

          colMeans(current_results, na.rm=TRUE)
        }

      }else{

        foreach::foreach(b=seq_len(nboot)) %do% {

          train_idx <- split_list[[b]]$train
          test_idx  <- split_list[[b]]$test

          octraining <- ocmat[train_idx,,drop=FALSE]
          octest     <- ocmat[test_idx,,drop=FALSE]

          if(!is.null(enmat)){
            envtraining <- enmat[train_idx,,drop=FALSE]
            envtest     <- enmat[test_idx,,drop=FALSE]
          }else{
            envtraining <- NULL
            envtest     <- NULL
          }

          sa_results <- runSA(octraining, enmat=envtraining,
                              rep=rep, threads=1, we=w,
                              totalit=totalit, lambda=l, intv=intv,
                              runadamW=runadamW, sparse=sparse,
                              getall=TRUE, reporting=FALSE)

          current_results <- testfittingSA(octest, sa_results,
                                           rep=rep, intv=intv,
                                           enmat=envtest)

          colMeans(current_results, na.rm=TRUE)
        }
      }

      current_results <- do.call(rbind, split_results)
      rownames(current_results) <- paste0("split_", seq_len(nboot))

      mean_results <- apply(current_results, 2, mean, na.rm=TRUE)

      if(fastfitting){
        min_err <- min(mean_results, na.rm=TRUE)

        top_results <- mean_results[mean_results <= min_err * (1 + tol)]
        top_results <- top_results[order(as.numeric(names(top_results)))]
        top_results <- top_results[1:min(length(top_results),5)]

        for(m in names(top_results)){
          min_points[[paste(l, w, as.integer(m), sep="_")]] <- as.numeric(top_results[m])
        }

      }else{
        top_results <- head(sort(mean_results), min(length(mean_results),5))

        for(m in names(top_results)){
          min_points[[paste(l, w, as.integer(m), sep="_")]] <- as.numeric(top_results[m])
        }
      }

      allresults[[combo_name]] <- current_results
    }
  }

  sorted_min_points <- min_points[order(sapply(min_points, function(x) x[1]))]

  return(list(
    head(sorted_min_points, min(length(min_points),5)),
    allresults
  ))
}



#'validateSA: to check the predictability of SA results by computing ocmatrix using
#'the estimated parameter set.
validateSA <- function(ocmat,h,j,g=NULL,enmat=NULL){
  if(is.null(enmat)){
    pp <- abs(1 - ocmat - 1 / (1 + exp(t(-h - t(ocmat %*% j)))))
  }
  else{
    pp <- abs(1 - ocmat - 1 / (1 + exp(-t(t(enmat %*% t(g)) + h) - ocmat %*% j)))
    #pp <- abs(1 - ocmat - 1 / (1 + exp(t(t(-hge - (ocmat %*% J))))))
  }
  return( -mean(log(pp[pp > 0])))
}
  

#'plotSAtest: plot the results of SA fitting (Findbp output)
#'@export
plotSAtest <- function(sa_results,ylim=c("auto","auto")){
  
  if(is.null(names(sa_results))){
    names(sa_results) <- paste0("set_", seq_along(sa_results))
  }
  
  summary_df <- data.frame()
  
  for(i in seq_along(sa_results)){
    res_serials_melt <- as.data.frame(sa_results[[i]]) %>%
      rownames_to_column("rowname") %>%
      gather(key="timepoint", value="value", -rowname)
    
    res_serials_melt$timepoint <- as.numeric(res_serials_melt$timepoint)
    res_serials_melt$id <- names(sa_results)[i]
    
    summary_df <- rbind(summary_df, res_serials_melt)
  }
  
  summary_mean <- summary_df %>%
    group_by(id,timepoint) %>%
    summarise(n=sum(!is.na(value)),
              mean=mean(value, na.rm=TRUE),
              sd=sd(value, na.rm=TRUE),
              .groups="drop") %>%
    mutate(sem=ifelse(n > 1, sd / sqrt(n), 0),
           tcrit=ifelse(n > 1, qt(0.975, n - 1), 0),
           CI_lower=mean - tcrit * sem,
           CI_upper=mean + tcrit * sem)
  
  if(ylim[[1]]=="auto"){
    ymin <- min(summary_mean$CI_lower, na.rm=TRUE)
  }else{
    ymin <- as.numeric(ylim[[1]])
  }
  
  if(ylim[[2]]=="auto"){
    ymax <- max(summary_mean$CI_upper, na.rm=TRUE)
  }else{
    ymax <- as.numeric(ylim[[2]])
  }
  
  ggplot(summary_mean, aes(x=timepoint, y=mean, color=id)) +
    geom_line(aes(color=id)) +
    geom_ribbon(aes(ymin=CI_lower, ymax=CI_upper, fill=id),
                color="grey70", alpha=0.4) +
    scale_y_continuous(limits=c(ymin,ymax))
}

