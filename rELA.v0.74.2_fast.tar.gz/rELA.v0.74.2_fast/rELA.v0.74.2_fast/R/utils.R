#'applymap: supporting function for Formatting
applymap <- function(df, fun){
  return(t(apply(df, 1, function(row){sapply(row, fun)})))
}

#'applyvec: supporting function for Formatting
applyvec <- function(df, fun){
  if(length(rownames(df)) > 1){
    output <- t(data.frame(lapply(t(df), fun))) %>% 'rownames<-'(rownames(df))
  }else(
    output <- data.frame(lapply(df, fun)) %>% 'colnames<-'(colnames(df))
  )
  return(output)
}

#'T: supporting function for Formatting
T <- function(df){return(as.data.frame(t(df)))}

#  Arguments: baseabtable, basemetadata: DataFrame
# normalize: 0 or 1
# parameters: list
# Returns: ocmatrix, abmatrix, fctmatrix: DataFrame
# samplelabel, taxonlabel, factorlabel: list

#'Formatting: generate data matrices from rawdata
#' @useDynLib rELA, .registration=TRUE
#' @export
Formatting <- function(baseabtable, basemetadata = NULL, normalize, parameters,
                       th_method = "global", grouping = 0, grouping_th = 0,
                       reporting = TRUE) {
  ath <- parameters[1]
  minocth <- parameters[2]
  maxocth <- parameters[3]
  maxval_th <- if (length(parameters) >= 4) parameters[4] else -1  # default = 100%

  group_table <- NULL  # prepare output

  if (length(basemetadata) != 0) {
    specieslabel <- colnames(baseabtable)
    absamplelabel <- rownames(baseabtable)
    mdsamplelabel <- rownames(basemetadata)
    sharedsamplelabel <- sort(intersect(absamplelabel, mdsamplelabel))
    patab <- match(sharedsamplelabel, absamplelabel)
    patmd <- match(sharedsamplelabel, mdsamplelabel)
    abnum <- baseabtable[patab, ]
    if (normalize == 1) {
      abnum <- t(apply(abnum, 1, function(x) x / (sum(x) + 1e-16)))
    }

    max_per_col <- apply(abnum, 2, max, na.rm = TRUE)
    keep_species <- names(max_per_col[max_per_col > maxval_th])
    abnum <- abnum[, keep_species, drop = FALSE]

    ath_vector <- switch(th_method,
      global = rep(ath, ncol(abnum)),
      max = apply(abnum, 2, max, na.rm = TRUE) * ath,
      median = apply(abnum, 2, median, na.rm = TRUE) * ath,
      stop("Invalid th_method: must be one of 'global', 'max', or 'median'")
    )
    names(ath_vector) <- colnames(abnum)

    aboc <- mapply(function(col, threshold) {
      ifelse(col >= threshold, 1, 0)
    }, as.data.frame(abnum), ath_vector)
    aboc <- as.matrix(aboc)
    rownames(aboc) <- rownames(abnum)
    colnames(aboc) <- colnames(abnum)

    aboc_mean <- apply(aboc, 2, mean)
    occrit <- names(aboc_mean[(aboc_mean > minocth) & (aboc_mean < maxocth)])
    ocmatrix <- aboc[, occrit, drop = FALSE]
    abmatrix <- abnum[, occrit, drop = FALSE]
    fctmatrix <- as.matrix(as.data.frame(basemetadata[patmd, ]))
    rownames(fctmatrix) <- rownames(ocmatrix)
    colnames(fctmatrix) <- colnames(basemetadata)
    samplelabel <- sharedsamplelabel
    specieslabel <- occrit
    factorlabel <- colnames(basemetadata)
  } else {
    specieslabel <- colnames(baseabtable)
    absamplelabel <- rownames(baseabtable)
    sharedsamplelabel <- sort(absamplelabel)
    patab <- match(sharedsamplelabel, absamplelabel)
    abnum <- baseabtable[patab, ]
    if (normalize == 1) {
      abnum <- t(apply(abnum, 1, function(x) x / (sum(x) + 1e-16)))
    }

    max_per_col <- apply(abnum, 2, max, na.rm = TRUE)
    keep_species <- names(max_per_col[max_per_col > 0.05])
    abnum <- abnum[, keep_species, drop = FALSE]

    ath_vector <- switch(th_method,
      global = rep(ath, ncol(abnum)),
      max = apply(abnum, 2, max, na.rm = TRUE) * ath,
      median = apply(abnum, 2, median, na.rm = TRUE) * ath,
      stop("Invalid th_method: must be one of 'global', 'max', or 'median'")
    )
    names(ath_vector) <- colnames(abnum)

    aboc <- mapply(function(col, threshold) {
      ifelse(col >= threshold, 1, 0)
    }, as.data.frame(abnum), ath_vector)
    aboc <- as.matrix(aboc)
    rownames(aboc) <- rownames(abnum)
    colnames(aboc) <- colnames(abnum)

    aboc_mean <- apply(aboc, 2, mean)
    occrit <- names(aboc_mean[(aboc_mean > minocth) & (aboc_mean < maxocth)])
    ocmatrix <- aboc[, occrit, drop = FALSE]
    abmatrix <- abnum[, occrit, drop = FALSE]
    fctmatrix <- NULL
    samplelabel <- sharedsamplelabel
    specieslabel <- occrit
    factorlabel <- NULL
  }



  if (grouping == 1) {
    ocvstr <- apply(ocmatrix, 2, function(y) paste(y, collapse = ""))
    oo <- order(ocvstr)
    ov <- ocvstr[oo]
    j <- ""
    cc <- 0
    binlist <- list()

    aaa <- foreach(i = ov) %do% {
      cc <- cc + 1
      if (stringdist(i, j, method = "hamming") / nchar(i) <= grouping_th) {
        a <- rev(binlist)[[1]]
        aa <- append(a, cc)
        binlist <- append(binlist[-length(binlist)], list(aa))
      } else {
        binlist <- append(binlist, list(cc))
      }
      j <- i
    }

    ltx <- length(specieslabel)

    # Prepare updated species labels (only for grouped entries)
    updated_specieslabel <- character(length(binlist))
    group_table_list <- list()
    group_counter <- 1

    for (k in seq_along(binlist)) {
      idx <- binlist[[k]]
      original_labels <- specieslabel[oo][idx]
      if (length(idx) > 1) {
        group_id <- paste0("Group_", group_counter)
        updated_specieslabel[k] <- group_id

        padded <- c(original_labels, rep(NA, max(lengths(binlist)) - length(original_labels)))
        names(padded) <- paste0("taxa_", seq_along(padded))
        group_table_list[[group_id]] <- padded

        group_counter <- group_counter + 1
      } else {
        updated_specieslabel[k] <- original_labels
      }
    }

    # Combine group table
    if (length(group_table_list) > 0) {
      group_table <- do.call(rbind, group_table_list)
      group_table <- as.data.frame(group_table, stringsAsFactors = FALSE)
      group_table <- tibble::rownames_to_column(group_table, var = "Group_ID")
    }

    specieslabel <- updated_specieslabel

    ocmatrix <- foreach(i = binlist, .combine = "cbind") %do% {
      ocmatrix[, oo][, i[1]]
    }
    abmatrix <- foreach(i = binlist, .combine = "cbind") %do% {
      if (length(i) > 1) {
        apply(abmatrix[, oo][, i], 1, sum)
      } else {
        abmatrix[, oo][, i]
      }
    }
    colnames(ocmatrix) <- specieslabel
    colnames(abmatrix) <- specieslabel
  }

  if (reporting) {
    cat("Processed", as.character(length(samplelabel)), "samples.\n")
    cat("Threshold method:", th_method, "\n")
    cat("Threshold value (ath):", ath, "\n")
    cat("Occurrence threshold range:", minocth, "~", maxocth, "\n")
    if (grouping == 1) {
      cat(as.character(ltx - length(specieslabel)), " groups were found.\n")
    }
    cat("Selected", as.character(length(specieslabel)), "of", as.character(ncol(baseabtable)), "species.\n")
  }

  return(list(
    ocmatrix = ocmatrix,
    abmatrix = abmatrix,
    fctmatrix = fctmatrix,
    samplelabel = samplelabel,
    specieslabel = specieslabel,
    factorlabel = factorlabel,
    group_table = group_table
  ))
}


#'dec2bin: supporting function for CInegerDigits
dec2bin <- function(num, digit=0){
  if(num <= 0 && digit <= 0){
    return(NULL)
  }else{
    return(append(Recall(num%/%2,digit-1), num%%2))
  }
}

#'CInegerDigits: map an integer to a binary vector
#' @useDynLib rELA, .registration=TRUE
#' @export
CIntegerDigits <- function(ssid, n, index=NULL){
  if(is.null(index)){index <- 1:n}
  if(is.numeric(ssid)){
    return(data.frame(dec2bin(ssid, n), row.names=index))
  }
  else{
    return(data.frame(id2bin(ssid, n), row.names=index))
  }
  }


#'str2i: map a binary vector to an integer (for large integers)
#' @export
str2i <- function(x) {
    y <- as.numeric(strsplit(x, "")[[1]])
    sum(y * 2^rev((seq_along(y)-1)))
}

#'bin2id: map a binary vector to a 36base characters
#' @export
bin2id <- function(bin){
  digs <- "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_/"
  bi <- unlist(bin)
  modi <- length(bi)%%6
  if(modi != 0){b0 <- rep(0, 6-modi)}else{b0<-c()}
  bii <- c(b0, bi)
  lb <- length(bii)
  aa <- foreach(i=seq(1, length(bii), 6), .combine="c") %do% {a <- rev(bii)[i:(i+5)]
                                s <- str2i(paste(as.character(rev(a)), collapse=""))
                                substr(digs, s+1, s+1)}
  return(paste(rev(aa), collapse=""))}

#'id2bin: map a 36base characters to a binary vector
#' @export
id2bin <-  function(id, s){
    digs <- "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_/"
    aa <- foreach (i=seq(1:nchar(id)), .combine="rbind") %do% {
        a <- substr(id,i,i)
        ia <- (unlist(gregexpr(a, digs))[1]) - 1
        CIntegerDigits(ia, 6)}
    uaa <- unlist(aa)
    aaa <- as.vector(uaa[(length(uaa)-s+1):length(uaa)])
    return(aaa)}

