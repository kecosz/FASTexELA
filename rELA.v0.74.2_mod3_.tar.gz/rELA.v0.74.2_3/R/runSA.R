#'Stochastic Approximation
#'@description Estimating species interaction, environemnt preference.
#'
#'@param ocmat : array of the vectors of presence/absence status for each sample. Row is sample, column is species.
#'@param enmat : array of the vectors of environmental factors for each sample. Normalization required.
#'@param we : the parameter for adamW.
#'@param lambda : the parameter for sparse matrix
#'@param rep : number of parallel processes for the optimization.
#'@param intv : interval of iterations recording intermediate fitting results.
#'@param totalit : total iterations of optimization
#'@param threads : number of cores (threads) used for calculation. 
#'@param getall : If TRUE, the function returns all intermediate results
#'@param reporting : enable/disable the reporting function.
#'
#' @useDynLib rELA, .registration=TRUE
#' @importFrom Rcpp sourceCpp
#' @importFrom foreach foreach
#' @export
runSA <- function(ocmat, enmat=NULL,  rep=128, threads=1, we=0.001, 
                  totalit=1000, lambda=0.01,intv=100, runadamW=TRUE, 
                  sparse=TRUE, getall=FALSE, reporting=TRUE){
    
    if(!sparse){lambda <- 0}
  
    if(!runadamW){we <- 0}
  
    if(threads>1){cluster = makeCluster(threads)
    clusterCall(cluster, function(x) .libPaths(x), .libPaths())
    registerDoParallel(cluster)
    on.exit(stopCluster(cluster))}

    if(is.null(enmat)){

    	## ============================================== ##
        ## -- without explicit variables

        if(reporting){cat('Start parameter fitting:\n')}
        s <- proc.time()[3]
        if(threads>1){fittingMat <- foreach(i = 1:rep, .packages="rELA") %dopar% {
            SAres <- SA(ocData = ocmat, we = we, totalit = totalit, 
                        lambda = lambda, intv = intv)
            return(SAres)
        }}else{fittingMat <- foreach(i = 1:rep) %do% {
	      if(reporting){cat('.')}
            SAres <- SA(ocData = ocmat, we = we, totalit = totalit, 
                        lambda = lambda, intv = intv)
            return(SAres)
        }}

        if(reporting){cat(sprintf('SA: elapsed time %.2f sec\n\n', proc.time()[3]-s))}
        ## ============================================== ##
      
        if(getall){
          return(fittingMat)
        }else{
            return(list(saEndpoint(fittingMat,ocmat),enmat))}
          
	    }else{

        ## ============================================== ##
        ## -- with explicit variables

        if(reporting){cat('Start parameter fitting\n')}
        s <- proc.time()[3]
        if(threads>1){fittingMat <- foreach(i = 1:rep, .packages="rELA") %dopar% {
            SAres <- fullSA(ocData = ocmat, envData=as.matrix(enmat), we = we, 
                            totalit = totalit, lambda = lambda, intv = intv)
            return(SAres)
        }}else{fittingMat <- foreach(i = 1:rep) %do% {
            if(reporting){cat('.')}
            SAres <- fullSA(ocData = ocmat, envData=as.matrix(enmat), we = we, 
                            totalit = totalit, lambda = lambda, intv = intv)
            return(SAres)
        }}

        if(reporting){cat(sprintf('SA: elapsed time %.2f sec\n\n', proc.time()[3]-s))}
        if(getall){
          return(fittingMat)
        }else{
          return(list(saEndpoint(fittingMat,ocmat,enmat=enmat),enmat))}
        ## ============================================== ##
	
    }
}


#'saEndpoint: extract endpoint parameters from runSA output
#' @export
saEndpoint <- function(fittingMat,ocmat,enmat=NULL){
  
  num_cols <- ncol(ocmat)
  packed_results_end <- lapply(fittingMat, 
                               function(x) x[(nrow(x) - num_cols + 1):nrow(x),])
  params_all <- lapply(packed_results_end, function(x) x[, 1:(ncol(x) - 2)])
  #upd <- lapply(sa, function(x) x[, (ncol(x) - 1):ncol(x)]) 
  
  params_mat <- params_all[[1]]
  for (n in 2:length(params_all)) {
    params_mat <- params_mat + params_all[[n]]
  }
  
  params_mat <- params_mat/length(params_all)
  rownames(params_mat) <- colnames(ocmat)
  
  if(is.null(enmat)){
    colnames(params_mat) <- c("h",paste('J',colnames(ocmat),sep='.'))
  }
  else{
    encols <- ncol(enmat)
    
    if( ncol(as.matrix(enmat))==1 ){
      gname <- paste('g', colnames(enmat), sep='.')
      ncols <- ncol(ocmat)+2
    }else{
      gname <- paste('g',1:ncol(enmat), sep='.')
      ncols <- ncol(ocmat)+ncol(enmat)+1
    }
    
    colnames(params_mat) <- c('h', gname, paste('J',colnames(ocmat),sep='.'))
  }
  
  return(params_mat)
}


#'sa2paramss: extract model parameters from runSA output
#' @useDynLib rELA, .registration=TRUE
#' @export
sa2params <- function(sa, env=NULL){
  sadim <- dim(sa[[1]])
  na <- rownames(sa[[1]])
  if(sadim[2] > sadim[1]+1){
      if(length(env)==0){env <- rep(0, sadim[2]-sadim[1]-1)} ## !!!
        he <- sa[[1]][, 1] %>% 'names<-'(na)
        je <- sa[[1]][, ((sadim[2]-sadim[1])+1):sadim[2]] %>% 'dimnames<-'(list(na,na))
        ge <- as.matrix(sa[[1]][,2:(sadim[2]-sadim[1])])  %>% 'dimnames<-' (list(na,colnames(sa[[2]])))
        hge <- (he + ge %*% env)[,1]
        #hge <- t(t(envecs %*% t(ge)) + he)
  }else{
        he <- sa[[1]][, 1] %>% 'names<-'(na)
        je <- sa[[1]][, -1] %>% 'dimnames<-'(list(na,na))
        ge <- NULL
        hge <- he
  }
  return(list(he, je, ge, hge))}


#'testfittingSA: testrun of SA across given parameter sets using subset of ocmatrix
testfittingSA <- function(ocmat,sa_results,rep,intv,enmat=NULL){
  nspecies = ncol(ocmat)
  num_timepoints <- nrow(sa_results[[1]]) / nspecies -1
  timepoints <- sapply(0:num_timepoints, function(x) (x + 1) * intv)
  serials <- 1:rep
  res_serials <- matrix(0, ncol= (num_timepoints+1), nrow=rep,
                       dimnames=list(serials,timepoints))
  for(i in 1:length(sa_results)){
    rowidx <- 1
    timeidx <- 1
    SAparams <- sa_results[[i]]
    while(rowidx < nrow(SAparams)){
      
      params<-sa2params(list(SAparams[rowidx:(rowidx+nspecies-1),
                                                  1:(ncol(SAparams)-2)],enmat))
      res_serials[i,timeidx] <- validateSA(ocmat,params[[1]],params[[2]],
                                           g=params[[3]],enmat=enmat)
      rowidx <- rowidx + nspecies
      timeidx <- timeidx + 1
    }
  }
  return(res_serials)
}
  
#'Findbp: Search the best parameters for SA fitting. If fastfitting=TRUE, then 
#'the function returns the minimum iterations allowing less than +3% errors than the minimum error.
#' @export
Findbp <- function(ocmat,enmat=NULL,cvmode=c("10fold","5fold","loo"),nrepeat=1,
                   we=c(0.001),
                   totalit=4000,lmd=c(0.001,0.1,0.2,0.25,0.4),
                   rep=1,intv=100,threads=16,tol=0.03,
                   runadamW=TRUE,sparse=TRUE,fastfitting=TRUE){

  min_points <- list()
  n_samples <- nrow(ocmat)

  if(n_samples < 2){
    stop("At least two samples are required.")
  }

  cvmode <- match.arg(cvmode)

  nrepeat <- as.integer(nrepeat)
  if(nrepeat < 1){
    stop("nrepeat must be >= 1.")
  }

  if(!runadamW){we <- c(0)}
  if(!sparse){lmd <- c(0)}

  ## ------------------------------------------------------------
  ## Make repeated cross-validation folds
  ## ------------------------------------------------------------

  split_list <- list()

  if(cvmode == "loo"){

    ## Leave-one-out is deterministic; nrepeat is ignored.
    for(i in seq_len(n_samples)){
      split_list[[length(split_list) + 1]] <- list(
        repeat_id = 1,
        fold_id = i,
        label = paste0("loo_", i),
        train = setdiff(seq_len(n_samples), i),
        test  = i
      )
    }

    split_prefix <- "loo"

  }else{

    k <- ifelse(cvmode == "10fold", 10, 5)

    if(n_samples < k){
      stop("Number of samples must be >= number of folds.")
    }

    for(r in seq_len(nrepeat)){

      ## Randomly assign samples to approximately equal-sized folds
      fold_id <- sample(rep(seq_len(k), length.out=n_samples))

      for(f in seq_len(k)){
        test_idx <- which(fold_id == f)
        train_idx <- setdiff(seq_len(n_samples), test_idx)

        split_list[[length(split_list) + 1]] <- list(
          repeat_id = r,
          fold_id = f,
          label = paste0("rep", r, "_fold", f),
          train = train_idx,
          test  = test_idx
        )
      }
    }

    split_prefix <- paste0(k, "fold")
  }

  n_splits <- length(split_list)

  ## ------------------------------------------------------------
  ## Make task grid:
  ## one task = one hyperparameter setting x one repeat/fold split
  ## ------------------------------------------------------------

  task_grid <- expand.grid(
    lambda = lmd,
    we = we,
    split_id = seq_len(n_splits),
    stringsAsFactors = FALSE
  )

  n_tasks <- nrow(task_grid)

  ## ------------------------------------------------------------
  ## Required packages
  ## ------------------------------------------------------------

  if(!requireNamespace("foreach", quietly=TRUE)){
    stop("Package 'foreach' is required.")
  }
  if(!requireNamespace("magrittr", quietly=TRUE)){
    stop("Package 'magrittr' is required.")
  }

  suppressPackageStartupMessages({
    library(foreach)
    library(magrittr)
  })

  ## ------------------------------------------------------------
  ## Parallel setup
  ## ------------------------------------------------------------

  use_parallel <- threads > 1

  if(use_parallel){

    if(!requireNamespace("doParallel", quietly=TRUE)){
      stop("Package 'doParallel' is required when threads > 1.")
    }

    n_workers <- min(threads, n_tasks)

    cluster <- parallel::makeCluster(n_workers)
    parallel::clusterCall(cluster, function(x) .libPaths(x), .libPaths())

    parallel::clusterEvalQ(cluster, {
      suppressPackageStartupMessages({
        library(foreach)
        library(magrittr)
        library(rELA)
      })
      NULL
    })

    doParallel::registerDoParallel(cluster)
    on.exit(parallel::stopCluster(cluster), add=TRUE)
  }

  ## ------------------------------------------------------------
  ## Run all tasks
  ## ------------------------------------------------------------

  run_one_task <- function(i){

    l <- task_grid$lambda[i]
    w <- task_grid$we[i]
    split_id <- task_grid$split_id[i]

    split <- split_list[[split_id]]

    train_idx <- split$train
    test_idx  <- split$test

    octraining <- ocmat[train_idx,,drop=FALSE]
    octest     <- ocmat[test_idx,,drop=FALSE]

    if(!is.null(enmat)){
      envtraining <- enmat[train_idx,,drop=FALSE]
      envtest     <- enmat[test_idx,,drop=FALSE]
    }else{
      envtraining <- NULL
      envtest     <- NULL
    }

    sa_results <- runSA(octraining, enmat=envtraining,
                        rep=rep, threads=1, we=w,
                        totalit=totalit, lambda=l, intv=intv,
                        runadamW=runadamW, sparse=sparse,
                        getall=TRUE, reporting=FALSE)

    current_results <- testfittingSA(octest, sa_results,
                                     rep=rep, intv=intv,
                                     enmat=envtest)

    ## Average across SA replicates within this split
    error_vec <- colMeans(current_results, na.rm=TRUE)

    list(
      lambda = l,
      we = w,
      split_id = split_id,
      split_label = split$label,
      repeat_id = split$repeat_id,
      fold_id = split$fold_id,
      error = error_vec
    )
  }

  task_results <- if(use_parallel){

    foreach::foreach(
      i = seq_len(n_tasks),
      .packages = c("foreach", "magrittr", "rELA"),
      .export = c("testfittingSA", "validateSA", "sa2params")
    ) %dopar% {
      run_one_task(i)
    }

  }else{

    lapply(seq_len(n_tasks), run_one_task)
  }

  ## ------------------------------------------------------------
  ## Reconstruct allresults in the same format:
  ## allresults[[lambda_we]] = matrix of CV errors
  ## rows = repeat/fold splits, columns = timepoints
  ## ------------------------------------------------------------

  allresults <- list()

  combo_names <- unique(paste(task_grid$lambda, task_grid$we, sep="_"))

  for(combo_name in combo_names){

    idx <- which(paste(task_grid$lambda, task_grid$we, sep="_") == combo_name)

    combo_results <- task_results[idx]

    current_results <- do.call(
      rbind,
      lapply(combo_results, function(x) x$error)
    )

    rownames(current_results) <- sapply(combo_results, function(x) x$split_label)

    allresults[[combo_name]] <- current_results
  }

  ## ------------------------------------------------------------
  ## Select best parameter/timepoint combinations
  ## ------------------------------------------------------------

  for(combo_name in names(allresults)){

    current_results <- allresults[[combo_name]]

    mean_results <- apply(current_results, 2, mean, na.rm=TRUE)

    combo_parts <- strsplit(combo_name, "_", fixed=TRUE)[[1]]
    l <- combo_parts[1]
    w <- combo_parts[2]

    if(fastfitting){

      min_err <- min(mean_results, na.rm=TRUE)

      top_results <- mean_results[mean_results <= min_err * (1 + tol)]
      top_results <- top_results[order(as.numeric(names(top_results)))]
      top_results <- top_results[1:min(length(top_results),5)]

      for(m in names(top_results)){
        min_points[[paste(l, w, as.integer(m), sep="_")]] <- as.numeric(top_results[m])
      }

    }else{

      top_results <- head(sort(mean_results), min(length(mean_results),5))

      for(m in names(top_results)){
        min_points[[paste(l, w, as.integer(m), sep="_")]] <- as.numeric(top_results[m])
      }
    }
  }

  sorted_min_points <- min_points[order(sapply(min_points, function(x) x[1]))]

  return(list(
    head(sorted_min_points, min(length(sorted_min_points),5)),
    allresults
  ))
}



#'validateSA: to check the predictability of SA results by computing ocmatrix using
#'the estimated parameter set.
validateSA <- function(ocmat,h,j,g=NULL,enmat=NULL){
  if(is.null(enmat)){
    pp <- abs(1 - ocmat - 1 / (1 + exp(t(-h - t(ocmat %*% j)))))
  }
  else{
    pp <- abs(1 - ocmat - 1 / (1 + exp(-t(t(enmat %*% t(g)) + h) - ocmat %*% j)))
    #pp <- abs(1 - ocmat - 1 / (1 + exp(t(t(-hge - (ocmat %*% J))))))
  }
  return( -mean(log(pp[pp > 0])))
}
  

#'plotSAtest: plot the results of SA fitting (Findbp output)
#'@export
plotSAtest <- function(sa_results,ylim=c("auto","auto")){
  
  if(is.null(names(sa_results))){
    names(sa_results) <- paste0("set_", seq_along(sa_results))
  }
  
  summary_df <- data.frame()
  
  for(i in seq_along(sa_results)){
    res_serials_melt <- as.data.frame(sa_results[[i]]) %>%
      rownames_to_column("rowname") %>%
      gather(key="timepoint", value="value", -rowname)
    
    res_serials_melt$timepoint <- as.numeric(res_serials_melt$timepoint)
    res_serials_melt$id <- names(sa_results)[i]
    
    summary_df <- rbind(summary_df, res_serials_melt)
  }
  
  summary_mean <- summary_df %>%
    group_by(id,timepoint) %>%
    summarise(n=sum(!is.na(value)),
              mean=mean(value, na.rm=TRUE),
              sd=sd(value, na.rm=TRUE),
              .groups="drop") %>%
    mutate(sem=ifelse(n > 1, sd / sqrt(n), 0),
           tcrit=ifelse(n > 1, qt(0.975, n - 1), 0),
           CI_lower=mean - tcrit * sem,
           CI_upper=mean + tcrit * sem)
  
  if(ylim[[1]]=="auto"){
    ymin <- min(summary_mean$CI_lower, na.rm=TRUE)
  }else{
    ymin <- as.numeric(ylim[[1]])
  }
  
  if(ylim[[2]]=="auto"){
    ymax <- max(summary_mean$CI_upper, na.rm=TRUE)
  }else{
    ymax <- as.numeric(ylim[[2]])
  }
  
  ggplot(summary_mean, aes(x=timepoint, y=mean, color=id)) +
    geom_line(aes(color=id)) +
    geom_ribbon(aes(ymin=CI_lower, ymax=CI_upper, fill=id),
                color="grey70", alpha=0.4) +
    scale_y_continuous(limits=c(ymin,ymax))
}

